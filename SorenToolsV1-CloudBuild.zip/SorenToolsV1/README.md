# Soren Tools V1 by Kepin

Android Studio project (Java, native Android UI), package `com.kepin.sorentools`.

## Build APK
1. Install Android Studio and Android SDK Platform 35 + Build Tools 35.
2. Open this folder in Android Studio and allow Gradle sync (Gradle 8.9 / Android Gradle Plugin 8.7.3).
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. APK output: `app/build/outputs/apk/debug/app-debug.apk`.

Minimum Android: 8.0 (API 26). Target SDK: 35 (Android 15); compatible with Android 13–16.

This starter app provides a dark/neon dashboard, device info, and shortcuts to standard Android settings. It does not perform root operations, game-memory injection, anti-cheat bypass, or silently change system settings.
