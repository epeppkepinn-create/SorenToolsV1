package com.kepin.sorentools;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.widget.*;
import java.io.File;

public class MainActivity extends Activity {
    private final int BG=Color.rgb(11,13,19), PANEL=Color.rgb(23,25,35), GREEN=Color.rgb(82,245,154), MUTED=Color.rgb(164,168,184);
    private LinearLayout root;
    @Override public void onCreate(Bundle b){ super.onCreate(b); getWindow().setStatusBarColor(BG); getWindow().setNavigationBarColor(BG); build(); }
    private GradientDrawable shape(int color,int stroke){ GradientDrawable d=new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(18)); if(stroke!=0)d.setStroke(dp(1),stroke); return d; }
    private int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
    private TextView text(String s,int size,int color,boolean bold){ TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); if(bold)t.setTypeface(null,Typeface.BOLD); return t; }
    private LinearLayout column(){ LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }
    private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w<0?w:dp(w),h<0?h:dp(h));}
    private void pad(View v,int a){v.setPadding(dp(a),dp(a),dp(a),dp(a));}
    private TextView button(String label,Runnable action){ TextView v=text(label,16,Color.WHITE,true); v.setGravity(Gravity.CENTER); v.setBackground(shape(PANEL,Color.rgb(75,78,92))); v.setPadding(dp(12),dp(17),dp(12),dp(17)); v.setOnClickListener(w->action.run()); return v; }
    private void build(){
        ScrollView scroll=new ScrollView(this); scroll.setFillViewport(true); root=column(); root.setPadding(dp(18),dp(18),dp(18),dp(24)); root.setBackgroundColor(BG); scroll.addView(root); setContentView(scroll);
        TextView title=text("soren tools v1",23,Color.WHITE,true); root.addView(title); TextView by=text("BY KEPIN  •  GAMING OPTIMIZER",11,GREEN,true); by.setPadding(0,dp(4),0,dp(18)); root.addView(by);
        TextView ready=text("  ✓  Soren Tools siap",14,Color.rgb(190,235,205),false); ready.setPadding(dp(12),dp(13),dp(12),dp(13)); ready.setBackground(shape(Color.rgb(20,39,31),0)); root.addView(ready,lp(-1,-2));
        LinearLayout info=column(); info.setGravity(Gravity.CENTER); info.setBackground(shape(PANEL,Color.rgb(48,52,69))); info.setPadding(dp(18),dp(22),dp(18),dp(18)); LinearLayout.LayoutParams ip=lp(-1,-2); ip.topMargin=dp(16); root.addView(info,ip);
        TextView logo=text("ST",32,GREEN,true); logo.setGravity(Gravity.CENTER); logo.setBackground(shape(Color.BLACK,0)); info.addView(logo,lp(76,76)); TextView heading=text("SOREN TOOLS V1",20,Color.WHITE,true); heading.setPadding(0,dp(14),0,dp(8)); info.addView(heading); TextView desc=text("Tools optimasi perangkat untuk pengalaman gaming yang lebih nyaman.\n\nFitur bekerja melalui fungsi Android standar; tidak mengubah atau menyuntikkan file game.",14,MUTED,false); desc.setGravity(Gravity.CENTER); info.addView(desc);
        TextView all=button("JALANKAN PEMERIKSAAN",()->runCheck()); LinearLayout.LayoutParams ap=lp(-1,58); ap.topMargin=dp(16); root.addView(all,ap);
        TextView revert=button("↻   Reset tampilan",()->{Toast.makeText(this,"Tidak ada perubahan sistem yang perlu dibatalkan.",Toast.LENGTH_SHORT).show();}); LinearLayout.LayoutParams rp=lp(-1,52); rp.topMargin=dp(10); root.addView(revert,rp);
        TextView section=text("STATUS PERANGKAT",13,MUTED,true); section.setPadding(0,dp(22),0,dp(10)); root.addView(section);
        LinearLayout row1=new LinearLayout(this); row1.setOrientation(LinearLayout.HORIZONTAL); root.addView(row1); row1.addView(stat("RAM",ram(),"Memori terpakai oleh sistem"),new LinearLayout.LayoutParams(0,dp(100),1)); View gap=new View(this); row1.addView(gap,lp(10,1)); row1.addView(stat("PENYIMPANAN",storage(),"Ruang tersedia"),new LinearLayout.LayoutParams(0,dp(100),1));
        LinearLayout row2=new LinearLayout(this); row2.setOrientation(LinearLayout.HORIZONTAL); LinearLayout.LayoutParams r2=lp(-1,100); r2.topMargin=dp(10); root.addView(row2,r2); row2.addView(stat("ANDROID",Build.VERSION.RELEASE,"Versi OS"),new LinearLayout.LayoutParams(0,dp(100),1)); View gap2=new View(this); row2.addView(gap2,lp(10,1)); row2.addView(stat("MODEL",Build.MODEL,"Perangkat"),new LinearLayout.LayoutParams(0,dp(100),1));
        TextView mods=text("MODUL",13,MUTED,true); mods.setPadding(0,dp(22),0,dp(10)); root.addView(mods);
        String[][] items={{"▣   Bloat check","Memeriksa aplikasi terpasang (tanpa menghapus)."},{"▤   Display","Buka pengaturan layar Android."},{"◉   Network","Buka pengaturan jaringan."},{"⚙   Power","Buka pengaturan baterai."},{"▦   Games","Buka daftar aplikasi."},{"⌁   Graphics","Buka pengaturan tampilan."}};
        for(int i=0;i<items.length;i+=2){ LinearLayout r=new LinearLayout(this); LinearLayout.LayoutParams rr=lp(-1,62); rr.topMargin=dp(8); root.addView(r,rr); for(int j=i;j<Math.min(i+2,items.length);j++){final int n=j; TextView b=button(items[j][0],()->module(n)); LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(0,-1,1); if(j%2==1)bp.leftMargin=dp(8); r.addView(b,bp);} }
        TextView foot=text("SOREN TOOLS V1 BY KEPIN  •  BUILD 1.0",10,MUTED,false); foot.setGravity(Gravity.CENTER); foot.setPadding(0,dp(24),0,dp(8)); root.addView(foot);
    }
    private View stat(String name,String value,String sub){ LinearLayout l=column(); l.setPadding(dp(13),dp(12),dp(8),dp(8)); l.setBackground(shape(PANEL,0)); l.addView(text(name,12,MUTED,false)); TextView v=text(value,16,Color.WHITE,true); v.setPadding(0,dp(5),0,dp(2)); l.addView(v); l.addView(text(sub,10,MUTED,false)); return l; }
    private String ram(){ ActivityManager am=(ActivityManager)getSystemService(ACTIVITY_SERVICE); ActivityManager.MemoryInfo mi=new ActivityManager.MemoryInfo(); am.getMemoryInfo(mi); return String.format(java.util.Locale.US,"%.1f GB",mi.totalMem/1073741824.0); }
    private String storage(){ long total=new File(getFilesDir().getAbsolutePath()).getTotalSpace(); long free=new File(getFilesDir().getAbsolutePath()).getFreeSpace(); return String.format(java.util.Locale.US,"%.1f GB free",free/1073741824.0); }
    private void runCheck(){ new AlertDialog.Builder(this).setTitle("Pemeriksaan selesai").setMessage("Informasi perangkat berhasil dibaca. Tidak ada perubahan sistem atau game yang dilakukan.").setPositiveButton("OK",null).show(); }
    private void module(int n){ String[] actions={"Bloat check","Display","Network","Power","Games","Graphics"}; String[] settings={null,android.provider.Settings.ACTION_DISPLAY_SETTINGS,android.provider.Settings.ACTION_WIRELESS_SETTINGS,android.provider.Settings.ACTION_BATTERY_SAVER_SETTINGS,null,android.provider.Settings.ACTION_DISPLAY_SETTINGS};
        if(n==0||n==4){ try{Intent i=new Intent(android.provider.Settings.ACTION_APPLICATION_SETTINGS); startActivity(i);}catch(Exception e){Toast.makeText(this,actions[n],Toast.LENGTH_SHORT).show();} return; }
        try{startActivity(new Intent(settings[n]));}catch(Exception e){Toast.makeText(this,"Pengaturan tidak tersedia di perangkat ini.",Toast.LENGTH_SHORT).show();}
    }
}
